<?php

use backend\models\Staff;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use kartik\time\TimePicker;

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">
    <?php
    $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data'],
                'action' => ['attendence/mark'],
                    ]
    );
    ?>
    <div class="row">

        <div class="col-md-4 col-md-offset-4"> <?php
            echo DatePicker::widget([
                'name' => 'daytime',
                'value' => $day_time,
                'options' => ['placeholder' => 'Select issue date ...'],
                'pluginOptions' => [
                    'format' => 'dd-M-yyyy',
                    'todayHighlight' => true,
                    'autoclose' => true,
                ]
            ]);
            ?></div>
    </div>
        <div class="row title_names">
        <div class="col-md-3">
            Name
        </div>
        <div class="col-md-3">
            Status<br>
              <input type="checkbox" id="checkAll"/ />
        </div>
        <div class="col-md-3">
            Time In
        </div>
        <div class="col-md-3">
            Time Out
        </div>   
    </div>
    <?php
    $resultu = $resultupData;

    foreach ($resultu as $resultup) {
        ?>
        <div class="row title_staff">
            <div class="col-md-3">
                <input type="hidden"  name="E[<?php echo $resultup['id']; ?>][id]"   value="<?php echo $resultup['name'] ?>" /><?php echo $resultup['name']; ?>
            </div>
            <div class="col-md-3">
                <input type="checkbox" <?php if($resultup['status'] == 1){echo 'checked="checked"';} ?> name="E[<?php echo $resultup['id']; ?>][status]" />

            </div>
            <div class="col-md-3">             
                <?=
                TimePicker::widget([
                    'name' => 'E[' . $resultup['id'] . '][time_in]',
                    'value' => $resultup['timein'],
                    'pluginOptions' => [
                        'showSeconds' => true
                    ]
                ]);
                ?>
            </div>
            <div class="col-md-3">
                <?=
                TimePicker::widget([
                    'name' => 'E[' . $resultup['id'] . '][time_out]',
                    'value' => $resultup['time_out'],
                    'pluginOptions' => [
                        'showSeconds' => true
                    ]
                ]);
                ?>
            </div>   
        </div>
    <?php } ?>
    <script>
    $("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});

    </script>
    <button class="btn btn-primary">Update</button>
<?php ActiveForm::end(); ?>

</div>
