<?php

use backend\models\Staff;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use kartik\time\TimePicker;

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">
    <?php
    $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data'],
                'action' => ['attendence/mark'],
                    ]
    );
    ?>
    <div class="row">               
        <div class="col-md-4 col-md-offset-2"> <?php
            echo DatePicker::widget([
                'name' => 'daytime',
                'value' => date('Y-m-d'),
                'options' => ['placeholder' => 'Select issue date ...'],
                'pluginOptions' => [
                    'format' => 'yyyy-mm-dd',
                    'todayHighlight' => true,
                    'autoclose' => true,
                ]
            ]);
            ?></div>
            <div class="col-md-4"> 
                <div class="col-md-6">
                Official Day
                </div>
                 <div class="col-md-6">
                <input name='is_offical' type="checkbox" checked>
                </div>
          </div>
    </div>   
    <div class="row title_names">
        <div class="col-md-3">
            Name
        </div>
        <div class="col-md-3">
            Status<br>
             <input type="checkbox" id="checkAll"/ />
        </div>
        <div class="col-md-3">
            Time In
        </div>
        <div class="col-md-3">
            Time Out
        </div>   
    </div>

    <?php
    $staf = Staff::find()
            ->all();

    foreach ($staf as $staff) {
        ?>

        <div class="row title_staff">
            <div class="col-md-3">

                <input type="hidden"  name="E[<?php echo $staff->id; ?>][id]"  name="<?php echo $staff->name; ?>" value="<?php echo $staff->id; ?>" /><?php echo $staff->name; ?>
            </div>
            <div class="col-md-3">
                <input type="checkbox" id="check<?php echo $staff->id; ?>" name="E[<?php echo $staff->id; ?>][status]" />

            </div>
            <div class="col-md-3">

                <?=
                TimePicker::widget([
                    'name' => 'E[' . $staff->id . '][time_in]',
                    'value' => '9:00 AM',
                    'pluginOptions' => [
                        'showSeconds' => true
                    ]
                ]);
                ?>
            </div>
            <div class="col-md-3">
                <?=
                TimePicker::widget([
                    'name' => 'E[' . $staff->id . '][time_out]',
                    'value' => '5:00 AM',
                    'pluginOptions' => [
                        'showSeconds' => true
                    ]
                ]);
                ?>

            </div>

        </div>
    <?php } ?>

    <button class="btn btn-primary">Save</button>
      <script>
    $("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});




    </script>

    <?php ActiveForm::end(); ?>

</div>
