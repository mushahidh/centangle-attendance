<?php

namespace backend\controllers;

use Yii;
use backend\models\Attendence;
use backend\models\AttendenceSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\Staff;
use yii\data\ActiveDataProvider;
use yii\data\Pagination;
use yii\data\ArrayDataProvider;

/**
 * AttendenceController implements the CRUD actions for Attendence model.
 */
class AttendenceController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Attendence models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AttendenceSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
    
        public function actionDatewise_attendence()
    {
        $searchModel = new AttendenceSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('datewise_attendence', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
    
    public function actionDailyat(){
        return $this->render('dailyat');
    }
    
          public function actionMarkupdate(){

       $this->render('/site/index');
    }

    /**
     * Displays a single Attendence model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Attendence model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Attendence();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }
        public function actionMark()
    {
     $model = new Attendence();
     if (Yii::$app->request->post()) {
     \Yii::$app
    ->db
    ->createCommand()
    ->delete('attendence', ['daytime' => Date('d-M-Y')])
    ->execute();
           $staf = Staff::find()   
           ->all();
            //var_dump($_POST);
           foreach($staf as $staff){
               $model->isNewRecord = true;
               $model->id = null;
               $model->staff_id = $staff->id;
                 if (isset($_POST['E'][$staff->id]['status'])){
                         $model->status = TRUE;
                          }
               else
                   $model->status = FALSE;
                $model->time_in = $_POST['E'][$staff->id]['time_in'];
               $model->time_out = $_POST['E'][$staff->id]['time_out'];
          
                   
                   $model->daytime = $_POST['daytime'];

                 $model->save(false);  
           }
              $dataProvider = new ActiveDataProvider;
    $dataProvider = (new \yii\db\Query())
    ->select(['daytime,count(case when status = 1  then 1 end) as present_count, count(case when status = 0 then 0 end) as absent_count '])
    ->from('attendence')

->groupBy(['daytime'])
    ->limit(10)->all();
// build a DB query to get all articles with status = 1
$resultData = (new \yii\db\Query())
    ->select(['id,daytime,count(case when status = 1  then 1 end) as present_count, count(case when status = 0 then 0 end) as absent_count '])
    ->from('attendence')

->groupBy(['daytime'])
        ->all();

    $dataProvider = new ArrayDataProvider([
        'key'=>'id',
        'allModels' => $resultData,
         'pagination' => [
        'pageSize' => 10,
    ],
        'sort' => [
            'attributes' => ['daytime', 'present_count', 'absent_count'],
        ],
]);  
     return $this->render('_item', [
        //'searchModel' => $searchModel,
        'dataProvider' => $dataProvider,
    ]);
    
 



         
     }
     }
   

    /**
     * Updates an existing Attendence model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Attendence model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Attendence model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Attendence the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Attendence::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
